class CatRentalRequest < ApplicationRecord
end
