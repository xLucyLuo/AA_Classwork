require 'test_helper'

class CatRentalRequreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
